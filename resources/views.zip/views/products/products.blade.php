{{-- @extends('default')

@section('title', 'Health and Safety Procedures')

@section('content')
    <div class="container">
        $products = [[{
            name: 'Product 1',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis lorem ut libero malesuada feugiat.',
            price: 19.99,
            image: 'https://via.placeholder.com/150' // Placeholder URL for the dummy image
        },
        {
            name: 'Product 2',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis lorem ut libero malesuada feugiat.',
            price: 29.99,
            image: 'https://via.placeholder.com/150' // Placeholder URL for the dummy image
        },
        {
            name: 'Product 3',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis lorem ut libero malesuada feugiat.',
            price: 24.99,
            image: 'https://via.placeholder.com/150' // Placeholder URL for the dummy image
        },
        {
            name: 'Product 4',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis lorem ut libero malesuada feugiat.',
            price: 34.99,
            image: 'https://via.placeholder.com/150' // Placeholder URL for the dummy image
        }
        // Add more products as needed
    ];
        <div class="row">
            <div class="col-md-8">
                <section id="main-container" class="main-container pb-2">
                    <div class="container">
                        <div class="row" id="product-container">
                            <!-- Product cards will be dynamically generated here -->
                        </div>
                    </div>
                    <!-- Container end -->
                </section>
                <!-- Section end -->
            </div>
            <!-- Col 8 end -->
        </div>
        <!-- Main row end -->
    </div>
    <!-- Container end -->
@endsection

<!-- jQuery CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 --}}
