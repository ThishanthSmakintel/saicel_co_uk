<!-- Bootstrap -->
<link rel="stylesheet" href="{{ asset('plugins/bootstrap/bootstrap.min.css') }}">

<!-- FontAwesome -->
<link rel="stylesheet" href="{{ asset('plugins/fontawesome/css/all.min.css') }}">

<!-- Animation -->
<link rel="stylesheet" href="{{ asset('plugins/animate-css/animate.css') }}">

<!-- slick Carousel -->
<link rel="stylesheet" href="{{ asset('plugins/slick/slick.css') }}">
<link rel="stylesheet" href="{{ asset('plugins/slick/slick-theme.css') }}">

<!-- Colorbox -->
<link rel="stylesheet" href="{{ asset('plugins/colorbox/colorbox.css') }}">

<!-- Template styles -->
<link rel="stylesheet" href="{{ asset('css/style.css') }}">

<!-- Include Slick Carousel CSS via CDN -->
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">

<!-- Include Slick Carousel theme CSS via CDN -->
<link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
