<!-- Initialize jQuery Library -->
<script src="{{ asset('plugins/jQuery/jquery.min.js') }}"></script>

<!-- Bootstrap jQuery -->
<script src="{{ asset('plugins/bootstrap/bootstrap.min.js') }}" defer></script>

<!-- Slick Carousel -->
<script src="{{ asset('plugins/slick/slick.min.js') }}"></script>
<script src="{{ asset('plugins/slick/slick-animation.min.js') }}"></script>

<!-- Colorbox -->
<script src="{{ asset('plugins/colorbox/jquery.colorbox.js') }}"></script>

<!-- Shuffle -->
<script src="{{ asset('plugins/shuffle/shuffle.min.js') }}" defer></script>

<!-- beforeafter Plugin -->
<script src="{{ asset('js/plugins/before-afer-js/beforeafter.jquery.js') }}" defer></script>


<!-- Template custom -->
<script src="{{ asset('js/script.js') }}"></script>
